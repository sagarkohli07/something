# Audio Folder

Place your MP3 files here with these exact names:

1. Dil Cheez Tujhe Dedi(KoshalWorld.Com).mp3
2. Pehla Nasha(KoshalWorld.Com).mp3

Or edit the song names in index.html (search for "const songs" in the JavaScript section).

## Supported Audio Formats
- MP3 (recommended)
- WAV
- OGG

Make sure your audio files are properly encoded and not corrupted.
